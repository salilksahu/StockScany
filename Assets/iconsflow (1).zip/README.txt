CC 3.0 BY  - Freepik http://bit.ly/19BNFd9: icon3.png
